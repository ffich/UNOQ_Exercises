# Exercise 2 - LED Blink with UI

In this exercise we will leverage the power of Bricks to create a more complex app. We'll still control a LED, but this time we'll use a Web UI to do that.

To implement the web UI we'll use a specialized Brick, called Web UI Streamlit.

As in the previous exercise, we will break down the functionalities between MPU and MCU:

- MPU: will implement the web User Interface
- MCU: will directly control the HW interface (GPIO)

### STEP 1: Implement the Sketch
The sketch implementation is pretty similar to the one of the previous exercise, so we start including the router bridge library (IMPORTANT NOTE: the library must be installed in order to be included, if is not installed you can install it from the install sketch library icon, present in the top left corner):

```
#include "Arduino_RouterBridge.h"
```

We need also to declare a global variable to hold the LED state (the high level python code will only ask the sketch to toggle the LED, so the state of the LED itself must be handled by the sketch logic)

```
bool led_state = false;
```

Now we move into the setup function and set the LED_BUILTIN channel as a digital OUTPUT:

```
void setup() {
    pinMode(LED_BUILTIN, OUTPUT);
}
```

Now we need to initialize the bridge (begin) and provide the function to control the LED:

```
void setup() {
    pinMode(LED_BUILTIN, OUTPUT);

    Bridge.begin();
    Bridge.provide("toggle_led", toggle_led);
}
```

That's it for the setup. In the main loop we don't have to do nothing in this case, as all we need is to implemen the set_led_state function.

This time the logic of the function is a bit different, we need to invert the state of led_state and use that logical value to set the LED state:

```
void loop() {
}

void toggle_led (void) {
    led_state = ! led_state;
    digitalWrite(LED_BUILTIN, led_state);
}
```

So the final form of the Sketch should be something like:

```
#include "Arduino_RouterBridge.h"

bool led_state = false;

void setup() {
    pinMode(LED_BUILTIN, OUTPUT);

    Bridge.begin();
    Bridge.provide("toggle_led", toggle_led);
}

void loop() {
}

void toggle_led (void) {
    led_state = ! led_state;
    digitalWrite(LED_BUILTIN, led_state);
}
```

## STEP 2: Implement the MPU python script

Now we can move into the MPU python script. First of all we need to import the Web UI - Streamlit bricks (from the Brick Icon on the top left corner).


Then we need to import the python side of the router library and also the st object from the stramlit_ui brick.

```
from arduino.app_utils import *
from arduino.app_bricks.streamlit_ui import st
```

Then we need to give to the We UI interface a title, and to do this we can use the title method:

```
st.title("Blink LED from UI Example")
```

Now we add a button and a conditional: if the button is pressed, we invoke the Bridge.call method to toggle the LED:

```
if st.button("Toggle LED"):
    Bridge.call("toggle_led")
```

The final implementation of the python script is as follows:

```
from arduino.app_utils import *
from arduino.app_bricks.streamlit_ui import st

st.title("Blink LED from UI Example")

if st.button("Toggle LED"):
    Bridge.call("toggle_led")
```    

### STEP 3: Run the App

Now press on the RUN button, on the top right corner to start the App. 