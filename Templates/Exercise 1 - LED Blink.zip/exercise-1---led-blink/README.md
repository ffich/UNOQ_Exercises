# Exercise 1 - LED Blink

In this simple exercise you will make an LED blink at 1Hz rate. Despite its simplicity, this exercise demonstrate an important new feature of Arduino UNO Q: the dual brain Architecture. In the Arduino UNO Q we have two different computation unit, the Qualcomm QRB2210 (MPU or SoC) and the ST STM32U585 (MCU). Eache one of these two units has different capability and is connected to a different set of peripherlas. In order to exploit the full potential of the board, each AppLab application (or app in short) provides two entry point (python script for the MPU and a classic Arduino Sketch for the MCU) and a specific communicatiomn infrastructure, called Arduino Router Bridge, that allows these two units to communucate.

In this example, we will separate the function of the two units in this way:

- MCU: exposes a funciton to control the LED_BUILTIN
- MPU: implements the main cycle

Let's implement the exercise step-by-step.

## STEP 1: Implement the MCU sketch

The first step is to implement the MCU skecth that exposes the Router service to access the LED. 

To do this, in the Sketch entry point include the router bridge library (IMPORTANT NODE: the library must be installed in order to be included, if is not installed you can install it from the install sketch library icon, present in the top left corner):

```
#include "Arduino_RouterBridge.h"
```

Then let's move into the setup function and set the LED_BUILTIN channel as a digital OUTPUT:

```
void setup() {
    pinMode(LED_BUILTIN, OUTPUT);
}
```

Now we need to initialize the bridge (begin) and provide the function to control the LED:

```
void setup() {
    pinMode(LED_BUILTIN, OUTPUT);

    Bridge.begin();
    Bridge.provide("set_led_state", set_led_state);
}
```

That's it for the setup. In the main loop we don't have to do nothing in this case, as all we need is to implemen the set_led_state function:

```
void loop() {
}

void set_led_state(bool state) {
    // LOW state means LED is ON
    digitalWrite(LED_BUILTIN, state ? LOW : HIGH);
}
```

So the final form of the Sketch should be something like:

```
#include "Arduino_RouterBridge.h"

void setup() {
    pinMode(LED_BUILTIN, OUTPUT);

    Bridge.begin();
    Bridge.provide("set_led_state", set_led_state);
}

void loop() {
}

void set_led_state(bool state) {
    // LOW state means LED is ON
    digitalWrite(LED_BUILTIN, state ? LOW : HIGH);
}
```


## STEP 2: Implement the MPU python script

Now we can move into the MPU python script. First of all we need to import the python side of the router library and also the python time library:

```
from arduino.app_utils import *
import time
```

Then we create a led_state variable, initialized to False, to hold the state of our LED (ON or OFF).

```
from arduino.app_utils import *
import time

led_state = False
```

The final step is to implment the main loop, where we wait for a second, invert the variable state and then use the Bridge.call method to call the MCU function passing the led_state parameter.

```
while(True):
    time.sleep(1)
    led_state = not led_state
    Bridge.call("set_led_state", led_state)
```

So the final form of the python script should be something like:

```
from arduino.app_utils import *
import time

led_state = False

while(True):
    time.sleep(1)
    led_state = not led_state
    Bridge.call("set_led_state", led_state)
```

### STEP 3: Run the App

Now press on the RUN button, on the top right corner to start the App. 
