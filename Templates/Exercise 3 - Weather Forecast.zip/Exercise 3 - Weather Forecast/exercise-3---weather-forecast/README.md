# Weather forecast on LED matrix

In this exercise you will create a simple weather forecast system, that uses the weather forecast brick to get the weather condition for a defined city and then display the weather information as an icon in the LED matrix display.

The **Weather Forecasting System** displays real-time weather information from the *open-meteo.com* service on the Arduino UNO Q LED matrix. It shows weather conditions like *sunny*, *cloudy*, *rainy*, *snowy* or *foggy* using animated visual patterns that update automatically every 10 seconds.

![Weather Forecasting App](assets/docs_assets/weather-forecast-banner.png)

## Description

The App fetches weather data from the *open-meteo.com* API for a specified city and converts weather codes into animated patterns on the 8 x 13 LED matrix. Each weather condition triggers its own distinctive animation sequence with carefully timed frame changes that simulate natural weather behavior.

The Python® script handles API communication and weather processing, while the Arduino sketch manages LED matrix animations and polling. The Router Bridge enables parameter passing between the Python environment and the microcontroller.


## STEP 1 - Python Script

IN this exercise, the first thing to do is to import the weather forecast Brick. Click on the Add Brick Icon on the top left corner and add the Weather Forecast Brick.

The Weather Forecast brick allows you to:

- Retrieve current and forecast weather data
- Query by city name (e.g. "Rome", "New York")
- Query by geographic coordinates (latitude & longitude)

It converts technical weather codes into simple categories, such as sunny, cloudy, rainy, snowy, or foggy, for easy integration with displays and applications. You can get weather forecasts for any city worldwide, specify forecast duration, and access weather codes, descriptions, and simplified categories with no API key required using the open-meteo.com service.

Now import the WeatherForecast object from the brick and import everything (*) from the app_utils as we have done for the previous exercises.

```python
from arduino.app_bricks.weather_forecast import WeatherForecast
from arduino.app_utils import *
```

After that instantiate a WeatherForecast Object:

```python
forecaster = WeatherForecast()
```

Now create a callable function get_weather_forecast that accept city as an input and return a simplified forecast.category. The category is a simplified
weather description, like sunny, cloudy, rainy, snowy, or foggy, that can be then used by the Arduino sketch to draw an icon on the Led Matrix.
The function also print some debug data.


```python
def get_weather_forecast(city: str) -> str:
    forecast = forecaster.get_forecast_by_city(city)
    print(f"Weather forecast for {city}: {forecast.description}, Category: {forecast.category}")
    return forecast.category
```

Now provide the function using the Bridge.provide Method, and start the script:

```python
Bridge.provide("get_weather_forecast", get_weather_forecast)

App.run()
```

The full python script is:
```python
from arduino.app_bricks.weather_forecast import WeatherForecast
from arduino.app_utils import *

forecaster = WeatherForecast()


def get_weather_forecast(city: str) -> str:
    forecast = forecaster.get_forecast_by_city(city)
    print(f"Weather forecast for {city}: {forecast.description}, Category: {forecast.category}")
    return forecast.category


Bridge.provide("get_weather_forecast", get_weather_forecast)

App.run()
```

## STEP 2 - Arduino Sketch

Now jump into the Arduino Sketch. Here start including the LED Martrix and the Bridge Libraries, and include also the file weather_frames.h that contains the 
weather icons definition for the LED Matrix and is already included in the template:

```cpp
#include <Arduino_LED_Matrix.h>
#include <Arduino_RouterBridge.h>

#include "weather_frames.h"
```

Now declare a String variable named city and initialize it with a city name, like this:

```cpp
String city = "Turin";
```

After that, instantiate an Arduino_LED_Matrix Object called matrix:

```cpp
Arduino_LED_Matrix matrix;
```

In the setup function you need to do the following things: call the begin and the clear method for the matrix object and call the begin method for the Bridge:

```cpp
void setup() {
  matrix.begin();
  matrix.clear();

  Bridge.begin();
}
```

In the loop function, you will:

- Declare a string variable called weather_forecast. This variable will hold the weather forecast category information that comes from the python script, when the bridge exposed function is called.
- Store the category result in the weather_forecast.
- Using a conditional expression (if..then..else or switch), check the category and draw the correspondign icon on the LED matrix

The Icon also has an animation, so you can use the playRepeat function (already present in the template) to animate the icon for a numbero of cycle, like this:

```cpp
    if (weather_forecast == "sunny") {
      matrix.loadSequence(sunny);
      playRepeat(10);
```

The full implementation of the loop function, for the following category:

- sunny
- cloudy
- rainy
- snowy
- foggy

is: 


```cpp
void loop() {
  String weather_forecast;
  bool ok = Bridge.call("get_weather_forecast", city).result(weather_forecast);
  if (ok) {
    if (weather_forecast == "sunny") {
      matrix.loadSequence(sunny);
      playRepeat(10);
    } else if (weather_forecast == "cloudy") {
      matrix.loadSequence(cloudy);
      playRepeat(10);
    } else if (weather_forecast == "rainy") {
      matrix.loadSequence(rainy);
      playRepeat(20);
    } else if (weather_forecast == "snowy") {
      matrix.loadSequence(snowy);
      playRepeat(10);
    } else if (weather_forecast == "foggy") {
      matrix.loadSequence(foggy);
      playRepeat(5);
    }
  }
}
```

The high-level data flow looks like this:

```
Arduino (city name) → Python® Bridge → Weather API → Animation Selection → LED Matrix Display
```

The full Arduino Sketch is:


```cpp
#include <Arduino_LED_Matrix.h>
#include <Arduino_RouterBridge.h>

#include "weather_frames.h"

String city = "Turin";

Arduino_LED_Matrix matrix;

void setup() {
  matrix.begin();
  matrix.clear();

  Bridge.begin();
}

void loop() {
  String weather_forecast;
  bool ok = Bridge.call("get_weather_forecast", city).result(weather_forecast);
  if (ok) {
    if (weather_forecast == "sunny") {
      matrix.loadSequence(sunny);
      playRepeat(10);
    } else if (weather_forecast == "cloudy") {
      matrix.loadSequence(cloudy);
      playRepeat(10);
    } else if (weather_forecast == "rainy") {
      matrix.loadSequence(rainy);
      playRepeat(20);
    } else if (weather_forecast == "snowy") {
      matrix.loadSequence(snowy);
      playRepeat(10);
    } else if (weather_forecast == "foggy") {
      matrix.loadSequence(foggy);
      playRepeat(5);
    }
  }
}

void playRepeat(int repeat_count) {
  for (int i = 0; i < repeat_count; i++) {
    matrix.playSequence();
  }
}
```

