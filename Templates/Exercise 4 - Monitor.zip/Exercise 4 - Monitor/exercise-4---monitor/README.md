# 🔍 Exedrcise 4 - Monitor

In this simple exercise we'll use the Monitor to send some debug information in the Sketch console.

### STEP 1: Sketch part

As in the other exercies we'll use the Arduino_RouterBridge library. So the first step is to import this library in the sketch:

```
#include "Arduino_RouterBridge.h"
```

Then in the Setup section, initialize the Monitor, calling the begin() method:

```
void setup() {
  Monitor.begin();
}
```

After that, in the loop, call the println() method to send a debug message and add a 1s delay:

```
void loop() {
  Monitor.println("Hello UNO Q");
  delay(1000);
}
```

You can now run the App, and check the debug messages in the Serial Monitor section.





