from arduino.app_utils import *
from arduino.app_bricks.streamlit_ui import st

st.title("Blink LED from UI Example")

if st.button("Toggle LED"):
    Bridge.call("toggle_led")