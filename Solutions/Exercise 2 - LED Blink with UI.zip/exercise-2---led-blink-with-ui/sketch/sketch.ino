#include "Arduino_RouterBridge.h"

bool led_state = false;

void setup() {
    pinMode(LED_BUILTIN, OUTPUT);

    Bridge.begin();
    Bridge.provide("toggle_led", toggle_led);
}

void loop() {
}

void toggle_led (void) {
    led_state = ! led_state;
    digitalWrite(LED_BUILTIN, led_state);
}
