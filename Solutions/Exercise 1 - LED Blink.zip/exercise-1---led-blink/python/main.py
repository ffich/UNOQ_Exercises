from arduino.app_utils import *
import time

led_state = False

while(True):
    time.sleep(1)
    led_state = not led_state
    Bridge.call("set_led_state", led_state)